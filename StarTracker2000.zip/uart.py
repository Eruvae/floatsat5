import serial
import time

# set up serial connection
serial = serial.Serial(
    port     = '/dev/ttyAMA0',
    baudrate = 115200,
    parity   = serial.PARITY_NONE,
    stopbits = serial.STOPBITS_ONE,
    bytesize = serial.EIGHTBITS,
    timeout  = 1
    )

# Read incoming UART serial data
def read():
    
    data = serial.readline()
    if data != '':
        print('received:')
        print(data)
    return data

def write(data):
    print('sent')
    print(data)
    serial.write(data)
    return

