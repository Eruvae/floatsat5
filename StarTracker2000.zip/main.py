import cv2
import picamera
import picamera.array
import time
import numpy
import uart
import radioPositioning
import starTracker
#import objectTracker as OT

# Constants
CAMERA_RESOLUTION = (320, 240)
CAMERA_BRIGHTNESS = 30
CAMERA_CONTRAST = 95
debug = False

# Initialise mode to idle, everything off
ST = False
OT = False
RD = False

# Read ST catalogs into memory
star_catalog = starTracker.read_catalog()

# Open Pi camera stream
with picamera.PiCamera() as camera:
    with picamera.array.PiRGBArray(camera) as stream:

        # Setup camera
        camera.resolution = CAMERA_RESOLUTION
        camera.brightness = CAMERA_BRIGHTNESS
        camera.contrast = CAMERA_CONTRAST

        # Main program loop
        while True:

            # Check for new command
            cmd = uart.read()
            
            # Enable/disable radio location
            if cmd == "$RD1\n":
                RD == True
            elif cmd == "$RD0\n":
                RD == False
            # Enable/disable star tracking
            elif cmd == "$ST1\n":
                ST = True
                OT = False    # turning on ST turns off OT and vice versa
            elif cmd == "$ST0\n":
                ST = False
            # Enable/disable object tracking
            elif cmd == "$OT1\n":
                OT = True
                ST = False
            elif cmd == "$OT0\n":
                OT = False                

            # Idle mode
            if ST == False and OT == False and RD == False:

                # can be removed
                time.sleep(0.1)

                uart.write("$OK\n")
                continue

            # Radio positioning
            if RD == True:

                data = radioPositioning.get_position()
                if data:
                    uart.write("$RD:%4.2f:%4.2f:%4.2f:%4.2f\n" % (data[0].x, data[0].y, data[1].x, data[1].y))
                    
            # Get camera stream for ST/OT
            camera.capture(stream, 'bgr', use_video_port=True)

            # Convert frame to greyscale
            frame = stream.array
            image = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

            # Star tracking
            if ST == True:

                data = starTracker.track_stars(image, star_catalog, True, debug)
                if data:
                    # convert mm to m
                    x = numpy.round(data['x'] / 1000.0, 4)
                    y = numpy.round(data['y'] / 1000.0, 4)
                    theta = data['theta']
                    uart.write("$ST:%4.2f:%4.2f:%4.2f\n" % (x, y, theta))

            # Object tracking
            if OT == True:
                print("Object tracking not implemented yet")
                
                #object_data = OT.track_objects(stream)
                #uart.write(object_data)

            # reset camera stream for next frame
            stream.seek(0)
            stream.truncate()

            # allow quitting of video with q
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break


# PI -->> STM serial data message formats
# $ is start character, \n end character
# ST=star tracking, OT=object tracking, RD=radio, OK=idle mode
# : is used as delimiter, values are floats
#
# $ST:12.234890:53.678:46.889\n
# $RD:12.123234:123.3534:123.234:25.453\n
# $OT:23.454:45.0\n
# $OK\n

# STM -->> PI serial command message formats
# eg ST1 turns on star tracking, OT0 turns off object, RD1 enables radio
#
# $ST1\n
# $ST0\n
# $OT0\n
# $OT1\n
# $RD1\n
# $RD0\n

