import requests
import json
import time

URL = 'http://192.168.1.1/website/src/val.js'

class LpsNode():
    def __init__(self, x=float(0), y=float(0), z=float(0), deadSince=int(0)):
        self.x = x
        self.y = y
        self.z = z
        self.deadSince = deadSince


def get_position():

    try:
        # call server and get JSON data
        resp = requests.get(URL)
        json = resp.json()

        # extract positions of vehicle 1 and 2
        veh1 = LpsNode()
        veh2 = LpsNode()
        
        veh1.x = float(json["N4"][0])
        veh1.y = float(json["N4"][1])
        veh1.z = float(json["N4"][2])
        veh1.deadSince = int(json["N4"][3])

        veh2.x = float(json["N5"][0])
        veh2.y = float(json["N5"][1])
        veh2.z = float(json["N5"][2])
        veh2.deadSince = int(json["N5"][3])

        return [veh1, veh2]

    except:
        print('FAILED to get radio positions')
        return
