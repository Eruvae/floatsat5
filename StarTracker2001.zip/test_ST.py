import cv2
import picamera
import picamera.array
import time
import numpy
import starTracker

# live camera or image from file?
USE_CAMERA = True

# camera config
CAMERA_RESOLUTION = (320, 240)
CAMERA_BRIGHTNESS = 60
CAMERA_CONTRAST = 95
CAMERA_SHUTTER = 10000

# image config
IMAGE_PATH = "./images/image1_0.jpg"

# read catalog
catalog = starTracker.read_catalog()

# Reading from camera
if USE_CAMERA:

    # Open Pi camera stream
    with picamera.PiCamera() as camera:

        # Setup camera
        camera.resolution    = CAMERA_RESOLUTION
        camera.brightness    = CAMERA_BRIGHTNESS
        camera.contrast      = CAMERA_CONTRAST
        camera.shutter_speed = CAMERA_SHUTTER
        
        with picamera.array.PiRGBArray(camera) as stream:

            while True:
                
                # Get camera frame as BGR array
                camera.capture(stream, 'bgr', use_video_port=True)

                # Convert frame to greyscale
                frame = stream.array
                image = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

                # Perform star tracking on current frame
                star_data = starTracker.track_stars(image, catalog, True, True)

                # reset stream for next frame
                stream.seek(0)
                stream.truncate()

                # handle exit button
                if cv2.waitKey(1) & 0xFF == ord('q'):
                    break

# Reading from file
else:
    
    image = cv2.imread(IMAGE_PATH)

    cv2.namedWindow('frame', cv2.WINDOW_NORMAL)
    cv2.imshow('frame', image)
    cv2.waitKey()

    while True:
        star_data = starTracker.track_stars(image, catalog, True, True)

        # handle exit button
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break


# close window (don't even ask)
cv2.destroyAllWindows()
for i in range(1,5):
    cv2.waitKey(1)    
